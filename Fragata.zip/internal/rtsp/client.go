package rtsp

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"net"
	"net/url"
	"strings"
	"time"

	"fragata/internal/stream"
	"github.com/bluenviron/gortsplib/v5"
	"github.com/bluenviron/gortsplib/v5/pkg/base"
	"github.com/bluenviron/gortsplib/v5/pkg/description"
	"github.com/bluenviron/gortsplib/v5/pkg/format"
	"github.com/bluenviron/gortsplib/v5/pkg/format/rtph264"
	"github.com/bluenviron/gortsplib/v5/pkg/format/rtph265"
	"github.com/pion/rtp"
)

type ProbeResult struct {
	URL             string `json:"url"`
	Codec           string `json:"codec"`
	Width           int    `json:"width,omitempty"`
	Height          int    `json:"height,omitempty"`
	AudioCodec      string `json:"audio_codec,omitempty"`
	AudioSampleRate int    `json:"audio_sample_rate,omitempty"`
	AudioChannels   int    `json:"audio_channels,omitempty"`
}

func WithCredentials(raw, username, password string) (string, error) {
	u, err := url.Parse(raw)
	if err != nil {
		return "", err
	}
	if u.Scheme != "rtsp" && u.Scheme != "rtsps" {
		return "", errors.New("la URL debe usar rtsp:// o rtsps://")
	}
	if username != "" {
		u.User = url.UserPassword(username, password)
	}
	return u.String(), nil
}

func WithoutCredentials(raw string) string {
	u, err := url.Parse(raw)
	if err != nil {
		return raw
	}
	u.User = nil
	return u.String()
}

func ExtractCredentials(raw string) (username, password string, ok bool) {
	u, err := url.Parse(raw)
	if err != nil || u.User == nil {
		return "", "", false
	}
	username = u.User.Username()
	password, _ = u.User.Password()
	return username, password, true
}

func NormalizeHost(raw, host string) string {
	u, err := url.Parse(raw)
	if err != nil {
		return raw
	}
	port := u.Port()
	if port == "" {
		port = "554"
		if u.Scheme == "rtsps" {
			port = "322"
		}
	}
	// Una cámara no debe poder redirigir la sonda a otro host mediante una URI ONVIF.
	u.Host = net.JoinHostPort(strings.Trim(host, "[]"), port)
	return u.String()
}

func Probe(ctx context.Context, rawURL string, timeout time.Duration) (ProbeResult, error) {
	u, err := base.ParseURL(rawURL)
	if err != nil {
		return ProbeResult{}, fmt.Errorf("URL RTSP inválida: %w", err)
	}
	protocol := gortsplib.ProtocolTCP
	c := &gortsplib.Client{
		Scheme: u.Scheme, Host: u.Host, Protocol: &protocol, ReadTimeout: timeout, WriteTimeout: timeout,
	}
	if err := c.Start(); err != nil {
		return ProbeResult{}, fmt.Errorf("conectar TCP RTSP a %s: %w", u.Host, err)
	}
	defer c.Close()

	done := make(chan struct{})
	go func() {
		select {
		case <-ctx.Done():
			c.Close()
		case <-done:
		}
	}()
	defer close(done)

	desc, _, err := c.Describe(u)
	if err != nil {
		return ProbeResult{}, fmt.Errorf("DESCRIBE RTSP: %w", err)
	}

	var (
		media  *description.Media
		forma  any
		codec  string
		width  int
		height int
	)
	var h264 *format.H264
	if found := desc.FindFormat(&h264); found != nil {
		media, forma, codec = found, h264, "H264"
		sps, _ := h264.SafeParams()
		width, height, _ = videoDimensions(codec, sps)
	} else {
		var h265 *format.H265
		if found := desc.FindFormat(&h265); found != nil {
			media, forma, codec = found, h265, "H265"
			_, sps, _ := h265.SafeParams()
			width, height, _ = videoDimensions(codec, sps)
		}
	}
	if media == nil {
		return ProbeResult{}, errors.New("el stream no contiene video H.264 ni H.265")
	}
	_, _, audioInfo := findSupportedAudio(desc)
	if _, err := c.Setup(desc.BaseURL, media, 0, 0); err != nil {
		return ProbeResult{}, fmt.Errorf("SETUP RTSP: %w", err)
	}
	packets := make(chan struct{}, 1)
	switch typed := forma.(type) {
	case *format.H264:
		c.OnPacketRTP(media, typed, func(*rtp.Packet) {
			select {
			case packets <- struct{}{}:
			default:
			}
		})
	case *format.H265:
		c.OnPacketRTP(media, typed, func(*rtp.Packet) {
			select {
			case packets <- struct{}{}:
			default:
			}
		})
	}
	if _, err := c.Play(nil); err != nil {
		return ProbeResult{}, fmt.Errorf("PLAY RTSP: %w", err)
	}
	timer := time.NewTimer(timeout)
	defer timer.Stop()
	select {
	case <-ctx.Done():
		return ProbeResult{}, ctx.Err()
	case <-timer.C:
		return ProbeResult{}, errors.New("el stream RTSP respondió pero no entregó video")
	case <-packets:
		return ProbeResult{URL: WithoutCredentials(rawURL), Codec: codec, Width: width, Height: height, AudioCodec: audioInfo.Codec, AudioSampleRate: audioInfo.SampleRate, AudioChannels: audioInfo.Channels}, nil
	}
}

func CommonCandidates(host string) []string {
	candidates := ExpandCandidates(host, []int{554}, nil, 96)
	out := make([]string, 0, len(candidates))
	for _, candidate := range candidates {
		out = append(out, candidate.URL)
	}
	return out
}

type Source struct {
	URL      string
	Width    int
	Height   int
	Hub      *stream.Hub
	OnPacket func(size int)
}

func (s *Source) Run(ctx context.Context) error {
	u, err := base.ParseURL(s.URL)
	if err != nil {
		return fmt.Errorf("URL RTSP inválida: %w", err)
	}
	protocol := gortsplib.ProtocolTCP
	c := &gortsplib.Client{
		Scheme: u.Scheme, Host: u.Host, Protocol: &protocol, ReadTimeout: 15 * time.Second, WriteTimeout: 10 * time.Second,
	}
	if err := c.Start(); err != nil {
		return fmt.Errorf("conectar RTSP: %w", err)
	}
	defer c.Close()

	desc, _, err := c.Describe(u)
	if err != nil {
		return fmt.Errorf("DESCRIBE RTSP: %w", err)
	}

	audioMedia, audioFormat, audioInfo := findSupportedAudio(desc)
	var h264 *format.H264
	if media := desc.FindFormat(&h264); media != nil {
		return s.runH264(ctx, c, desc.BaseURL, media, h264, audioMedia, audioFormat, audioInfo)
	}
	var h265 *format.H265
	if media := desc.FindFormat(&h265); media != nil {
		return s.runH265(ctx, c, desc.BaseURL, media, h265, audioMedia, audioFormat, audioInfo)
	}
	return errors.New("stream sin formato H.264/H.265")
}

func (s *Source) runH264(ctx context.Context, c *gortsplib.Client, baseURL *base.URL, media *description.Media, forma *format.H264, audioMedia *description.Media, audioFormat format.Format, audioInfo stream.AudioInfo) error {
	decoder, err := forma.CreateDecoder()
	if err != nil {
		return fmt.Errorf("crear decoder RTP/H264: %w", err)
	}
	if _, err := c.Setup(baseURL, media, 0, 0); err != nil {
		return fmt.Errorf("SETUP RTSP: %w", err)
	}
	if audioMedia != nil && audioFormat != nil {
		if _, err := c.Setup(baseURL, audioMedia, 0, 0); err != nil {
			audioMedia, audioFormat = nil, nil
		}
	}
	generation := s.Hub.BeginSource()
	defer s.Hub.EndSource(generation)
	sps, pps := forma.SafeParams()
	width, height := sourceDimensions("H264", s.Width, s.Height, sps)
	s.Hub.SetInfo(stream.Info{Codec: "H264", Width: width, Height: height, SPS: sps, PPS: pps})
	s.configureAudio(c, audioMedia, audioFormat, audioInfo, generation)

	c.OnPacketRTP(media, forma, func(pkt *rtp.Packet) {
		if s.OnPacket != nil {
			s.OnPacket(len(pkt.Payload))
		}
		s.Hub.PublishRTP(pkt)
		pts, ok := c.PacketPTS(media, pkt)
		if !ok {
			return
		}
		au, decErr := decoder.Decode(pkt)
		if decErr != nil {
			if !errors.Is(decErr, rtph264.ErrNonStartingPacketAndNoPrevious) && !errors.Is(decErr, rtph264.ErrMorePacketsNeeded) {
				return
			}
			return
		}
		key := false
		paramsChanged := false
		for _, nalu := range au {
			if len(nalu) == 0 {
				continue
			}
			switch nalu[0] & 0x1f {
			case 5:
				key = true
			case 7:
				if !bytes.Equal(sps, nalu) {
					sps = append([]byte(nil), nalu...)
					paramsChanged = true
				}
			case 8:
				if !bytes.Equal(pps, nalu) {
					pps = append([]byte(nil), nalu...)
					paramsChanged = true
				}
			}
		}
		if paramsChanged {
			width, height = sourceDimensions("H264", s.Width, s.Height, sps)
			s.Hub.SetInfo(stream.Info{Codec: "H264", Width: width, Height: height, SPS: sps, PPS: pps})
		}
		s.Hub.PublishAccessUnit(stream.AccessUnit{PTS: rtpTimestampDuration(pts, forma.ClockRate()), NALUs: au, KeyFrame: key, Generation: generation})
	})
	return playUntilDone(ctx, c)
}

func (s *Source) runH265(ctx context.Context, c *gortsplib.Client, baseURL *base.URL, media *description.Media, forma *format.H265, audioMedia *description.Media, audioFormat format.Format, audioInfo stream.AudioInfo) error {
	decoder, err := forma.CreateDecoder()
	if err != nil {
		return fmt.Errorf("crear decoder RTP/H265: %w", err)
	}
	if _, err := c.Setup(baseURL, media, 0, 0); err != nil {
		return fmt.Errorf("SETUP RTSP: %w", err)
	}
	if audioMedia != nil && audioFormat != nil {
		if _, err := c.Setup(baseURL, audioMedia, 0, 0); err != nil {
			audioMedia, audioFormat = nil, nil
		}
	}
	generation := s.Hub.BeginSource()
	defer s.Hub.EndSource(generation)
	vps, sps, pps := forma.SafeParams()
	width, height := sourceDimensions("H265", s.Width, s.Height, sps)
	s.Hub.SetInfo(stream.Info{Codec: "H265", Width: width, Height: height, VPS: vps, SPS: sps, PPS: pps})
	s.configureAudio(c, audioMedia, audioFormat, audioInfo, generation)

	c.OnPacketRTP(media, forma, func(pkt *rtp.Packet) {
		if s.OnPacket != nil {
			s.OnPacket(len(pkt.Payload))
		}
		s.Hub.PublishRTP(pkt)
		pts, ok := c.PacketPTS(media, pkt)
		if !ok {
			return
		}
		au, decErr := decoder.Decode(pkt)
		if decErr != nil {
			if !errors.Is(decErr, rtph265.ErrNonStartingPacketAndNoPrevious) && !errors.Is(decErr, rtph265.ErrMorePacketsNeeded) {
				return
			}
			return
		}
		key := false
		paramsChanged := false
		for _, nalu := range au {
			if len(nalu) < 2 {
				continue
			}
			typ := (nalu[0] >> 1) & 0x3f
			switch typ {
			case 16, 17, 18, 19, 20, 21:
				key = true
			case 32:
				if !bytes.Equal(vps, nalu) {
					vps = append([]byte(nil), nalu...)
					paramsChanged = true
				}
			case 33:
				if !bytes.Equal(sps, nalu) {
					sps = append([]byte(nil), nalu...)
					paramsChanged = true
				}
			case 34:
				if !bytes.Equal(pps, nalu) {
					pps = append([]byte(nil), nalu...)
					paramsChanged = true
				}
			}
		}
		if paramsChanged {
			width, height = sourceDimensions("H265", s.Width, s.Height, sps)
			s.Hub.SetInfo(stream.Info{Codec: "H265", Width: width, Height: height, VPS: vps, SPS: sps, PPS: pps})
		}
		s.Hub.PublishAccessUnit(stream.AccessUnit{PTS: rtpTimestampDuration(pts, forma.ClockRate()), NALUs: au, KeyFrame: key, Generation: generation})
	})
	return playUntilDone(ctx, c)
}

func findSupportedAudio(desc *description.Session) (*description.Media, format.Format, stream.AudioInfo) {
	if desc == nil {
		return nil, nil, stream.AudioInfo{}
	}
	for _, media := range desc.Medias {
		for _, forma := range media.Formats {
			info := audioFormatInfo(forma)
			if info.Codec != "" {
				return media, forma, info
			}
		}
	}
	return nil, nil, stream.AudioInfo{}
}

func audioFormatInfo(forma format.Format) stream.AudioInfo {
	switch typed := forma.(type) {
	case *format.G711:
		codec := "PCMA"
		if typed.MULaw {
			codec = "PCMU"
		}
		channels := typed.ChannelCount
		if channels < 1 {
			channels = 1
		}
		return stream.AudioInfo{Codec: codec, SampleRate: typed.SampleRate, Channels: channels}
	case *format.Opus:
		channels := typed.ChannelCount
		if channels < 1 || channels > 2 {
			return stream.AudioInfo{}
		}
		return stream.AudioInfo{Codec: "OPUS", SampleRate: typed.ClockRate(), Channels: channels}
	case *format.MPEG4Audio:
		if typed.Config == nil {
			return stream.AudioInfo{}
		}
		private, err := typed.Config.Marshal()
		if err != nil || len(private) == 0 {
			return stream.AudioInfo{}
		}
		channels := int(typed.Config.ChannelConfig)
		if channels == 7 {
			channels = 8
		}
		if channels < 1 || channels > 8 {
			channels = 1
		}
		return stream.AudioInfo{Codec: "AAC", SampleRate: typed.ClockRate(), Channels: channels, CodecPrivate: private}
	default:
		return stream.AudioInfo{}
	}
}

func (s *Source) configureAudio(c *gortsplib.Client, media *description.Media, forma format.Format, info stream.AudioInfo, generation uint64) {
	if media == nil || forma == nil || info.Codec == "" {
		return
	}
	if aac, ok := forma.(*format.MPEG4Audio); ok {
		decoder, err := aac.CreateDecoder()
		if err != nil {
			return
		}
		s.Hub.SetAudioInfo(info)
		c.OnPacketRTP(media, aac, func(pkt *rtp.Packet) {
			if s.OnPacket != nil {
				s.OnPacket(len(pkt.Payload))
			}
			pts, ok := c.PacketPTS(media, pkt)
			if !ok {
				return
			}
			ausus, err := decoder.Decode(pkt)
			if err != nil {
				return
			}
			basePTS := rtpTimestampDuration(pts, aac.ClockRate())
			frameDuration := 1024 * time.Second / time.Duration(aac.ClockRate())
			for index, au := range ausus {
				s.Hub.PublishAudio(stream.AudioPacket{
					PTS: basePTS + time.Duration(index)*frameDuration, Payload: au, Generation: generation,
				})
			}
		})
		return
	}
	s.Hub.SetAudioInfo(info)
	c.OnPacketRTP(media, forma, func(pkt *rtp.Packet) {
		if s.OnPacket != nil {
			s.OnPacket(len(pkt.Payload))
		}
		pts, ok := c.PacketPTS(media, pkt)
		if !ok {
			return
		}
		s.Hub.PublishAudio(stream.AudioPacket{
			PTS: rtpTimestampDuration(pts, forma.ClockRate()), Payload: pkt.Payload, RTP: pkt,
			Generation: generation,
		})
	})
}

func playUntilDone(ctx context.Context, c *gortsplib.Client) error {
	if _, err := c.Play(nil); err != nil {
		return fmt.Errorf("PLAY RTSP: %w", err)
	}
	closed := make(chan struct{})
	go func() {
		select {
		case <-ctx.Done():
			c.Close()
		case <-closed:
		}
	}()
	err := c.Wait()
	close(closed)
	if ctx.Err() != nil {
		return ctx.Err()
	}
	return err
}

func sourceDimensions(codec string, configuredWidth, configuredHeight int, sps []byte) (int, int) {
	if configuredWidth > 0 && configuredHeight > 0 {
		return configuredWidth, configuredHeight
	}
	width, height, err := videoDimensions(codec, sps)
	if err == nil {
		return width, height
	}
	return 0, 0
}

func rtpTimestampDuration(value int64, clockRate int) time.Duration {
	if clockRate <= 0 {
		return 0
	}
	rate := int64(clockRate)
	seconds := value / rate
	remainder := value % rate
	return time.Duration(seconds)*time.Second + time.Duration(remainder)*time.Second/time.Duration(rate)
}
